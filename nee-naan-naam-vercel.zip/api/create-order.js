// POST /api/create-order — creates a Razorpay order for the chosen pass and quantity.
const { keys, configured, readBody, guestFrom, razorpay } = require('./_lib');

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  if (!configured()) return res.status(503).json({ error: 'Payments are not switched on yet.', code: 'not_configured' });
  const g = guestFrom(readBody(req));
  if (g.error) return res.status(400).json({ error: g.error });
  const receipt = 'NNN-' + Date.now().toString(36).toUpperCase() + '-' + Math.random().toString(36).slice(2, 6).toUpperCase();
  try {
    const order = await razorpay('/orders', {
      method: 'POST',
      body: JSON.stringify({
        amount: g.amount, currency: 'INR', receipt,
        notes: { event: 'Nee Naan Naam · 25 Dec 2026', pass: g.pass.name, quantity: String(g.qty), guests: String(g.qty * 2), name: g.name, email: g.email, phone: g.phone, song: g.song }
      })
    });
    res.status(200).json({ orderId: order.id, amount: order.amount, currency: order.currency, receipt, keyId: keys().id });
  } catch (e) {
    console.error('create-order', e.message);
    res.status(502).json({ error: 'Could not start the payment.' });
  }
};

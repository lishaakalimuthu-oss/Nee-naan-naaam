// GET /api/health — open this in a browser to check Razorpay is set up (never shows the secret).
const { keys, configured } = require('./_lib');
module.exports = (req, res) => {
  const id = keys().id;
  res.status(200).json({ razorpay: configured() ? 'configured' : 'missing keys', mode: id.startsWith('rzp_live_') ? 'live' : id.startsWith('rzp_test_') ? 'test' : 'unknown' });
};

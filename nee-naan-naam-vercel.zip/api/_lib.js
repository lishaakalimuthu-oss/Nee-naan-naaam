// Shared helpers for the Razorpay API routes.
// Prices live HERE on the server so nobody can change the amount from the browser.
// Keep these in step with the tickets in index.html (window.NNN_CONFIG.tickets).
const crypto = require('crypto');

const PASSES = {
  couple: { name: 'Couple Pass', price: 3999 } // ₹ — early bird (regular ₹4,999). Change to 4999 when early bird ends.
};
const MAX_QTY = 6;

const keys = () => ({ id: process.env.RAZORPAY_KEY_ID || '', secret: process.env.RAZORPAY_KEY_SECRET || '' });
const configured = () => { const k = keys(); return Boolean(k.id && k.secret); };

function readBody(req) {
  if (req.body && typeof req.body === 'object') return req.body;
  try { return JSON.parse(req.body || '{}'); } catch (_) { return {}; }
}

const clean = (v, n) => String(v == null ? '' : v).replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, n);

function guestFrom(body) {
  const pass = PASSES[body.ticketId];
  const qty = Math.floor(Number(body.qty));
  const name = clean(body.name, 80), email = clean(body.email, 120), phone = clean(body.phone, 20), song = clean(body.song, 120);
  if (!pass) return { error: 'Unknown pass.' };
  if (!(qty >= 1 && qty <= MAX_QTY)) return { error: 'Invalid quantity.' };
  if (name.length < 2 || !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email) || phone.replace(/\D/g, '').length < 10) return { error: 'Please check your details.' };
  return { pass, ticketId: body.ticketId, qty, name, email, phone, song, amount: pass.price * qty * 100 };
}

async function razorpay(path, opts = {}) {
  const k = keys();
  const r = await fetch('https://api.razorpay.com/v1' + path, {
    ...opts,
    headers: { 'Content-Type': 'application/json', Authorization: 'Basic ' + Buffer.from(k.id + ':' + k.secret).toString('base64') }
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error((data.error && data.error.description) || 'Razorpay error ' + r.status);
  return data;
}

function signatureOk(orderId, paymentId, signature) {
  const expected = crypto.createHmac('sha256', keys().secret).update(orderId + '|' + paymentId).digest('hex');
  const a = Buffer.from(expected), b = Buffer.from(String(signature || ''));
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

module.exports = { PASSES, keys, configured, readBody, guestFrom, razorpay, signatureOk };

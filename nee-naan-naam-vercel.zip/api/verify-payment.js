// POST /api/verify-payment — checks Razorpay's signature, then confirms the payment with Razorpay.
const { configured, readBody, razorpay, signatureOk } = require('./_lib');

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  if (!configured()) return res.status(503).json({ ok: false, code: 'not_configured' });
  const b = readBody(req);
  const orderId = b.razorpay_order_id, paymentId = b.razorpay_payment_id;
  if (!orderId || !paymentId || !signatureOk(orderId, paymentId, b.razorpay_signature)) return res.status(400).json({ ok: false, error: 'Signature mismatch' });
  try {
    const [order, payment] = await Promise.all([razorpay('/orders/' + orderId), razorpay('/payments/' + paymentId)]);
    const paid = payment.order_id === orderId && ['captured', 'authorized'].includes(payment.status) && payment.amount === order.amount;
    if (!paid) return res.status(402).json({ ok: false, error: 'Payment not completed' });
    res.status(200).json({ ok: true, bookingRef: order.receipt, paymentId, amount: payment.amount });
  } catch (e) {
    console.error('verify-payment', e.message);
    res.status(502).json({ ok: false, error: 'Could not confirm the payment.' });
  }
};
